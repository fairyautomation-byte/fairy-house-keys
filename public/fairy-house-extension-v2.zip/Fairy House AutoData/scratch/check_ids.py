import re

def check(name, js_path, html_path):
    print(f"\n=== Checking {name} ===")
    with open(js_path, 'r', encoding='utf-8') as f:
        js_content = f.read()

    with open(html_path, 'r', encoding='utf-8') as f:
        html_content = f.read()

    pattern_js = r"(?:\$|getElementById)\(['\"]([a-zA-Z0-9_\-]+)['\"]\)"
    js_ids = set(re.findall(pattern_js, js_content))

    pattern_html = r"id=['\"]([a-zA-Z0-9_\-]+)['\"]"
    html_ids = set(re.findall(pattern_html, html_content))

    missing = sorted(js_ids - html_ids)
    print(f"Total IDs in {js_path}: {len(js_ids)}")
    print(f"Total IDs in {html_path}: {len(html_ids)}")
    if missing:
        print(f"MISSING {len(missing)} IDs in {html_path}:")
        for m in missing:
            print(" -", m)
    else:
        print(f"SUCCESS: All {js_path} IDs are present in {html_path}!")

check("Modal Workstation", "src/ui/modal.js", "src/ui/modal.html")
check("Action Popup", "src/ui/action-popup.js", "src/ui/action-popup.html")


