
    function switchAppView(viewName) {
      var leadsView = document.getElementById('zt-view-leads');
      var analyticsView = document.getElementById('zt-sidebar');
      var setupView = document.getElementById('zt-section-config');
      var workspaceSection = document.getElementById('zt-section-workspace');
      var tabLeads = document.getElementById('zt-nav-tab-leads');
      var tabAnalytics = document.getElementById('zt-nav-tab-analytics');
      var tabSetup = document.getElementById('zt-nav-tab-setup');

      // Reset all nav tabs
      [tabLeads, tabAnalytics, tabSetup].forEach(function(tab) {
        if (!tab) return;
        tab.classList.remove('active');
      });

      if (viewName === 'analytics') {
        if (tabAnalytics) tabAnalytics.classList.add('active');
        if (workspaceSection) {
          workspaceSection.classList.remove('hidden');
          workspaceSection.classList.add('flex');
        }
        if (leadsView) leadsView.classList.add('hidden');
        if (analyticsView) {
          analyticsView.classList.remove('hidden');
          analyticsView.classList.add('zt-analytics-active');
        }
        if (setupView) setupView.classList.add('hidden');
      } else if (viewName === 'setup') {
        if (tabSetup) tabSetup.classList.add('active');
        if (workspaceSection) workspaceSection.classList.add('hidden');
        if (leadsView) leadsView.classList.add('hidden');
        if (analyticsView) {
          analyticsView.classList.add('hidden');
          analyticsView.classList.remove('zt-analytics-active');
        }
        if (setupView) setupView.classList.remove('hidden');
      } else {
        // Default: 'leads'
        if (tabLeads) tabLeads.classList.add('active');
        if (workspaceSection) {
          workspaceSection.classList.remove('hidden');
          workspaceSection.classList.add('flex');
        }
        if (leadsView) leadsView.classList.remove('hidden');
        if (analyticsView) {
          analyticsView.classList.add('hidden');
          analyticsView.classList.remove('zt-analytics-active');
        }
        if (setupView) setupView.classList.add('hidden');
      }
    }

    // Reactive Status & Floating Dock Manager
    document.addEventListener('DOMContentLoaded', function() {
      var configSec = document.getElementById('zt-section-config');
      var scanSec = document.getElementById('zt-section-scan');

      // Initial active tab coordination
      if (configSec && !configSec.classList.contains('hidden') && scanSec && scanSec.classList.contains('hidden')) {
        switchAppView('setup');
      }

      // Auto-switch to leads when scan begins
      if (scanSec) {
        new MutationObserver(function() {
          if (!scanSec.classList.contains('hidden')) {
            var tabSetup = document.getElementById('zt-nav-tab-setup');
            if (tabSetup && tabSetup.classList.contains('active')) {
              switchAppView('leads');
            }
          }
        }).observe(scanSec, { attributes: true, attributeFilter: ['class'] });
      }

      // Mirror Phone counter to Left Rail Badge
      var statPhones = document.getElementById('zt-stat-phones');
      var navCountLeads = document.getElementById('zt-nav-count-leads');
      if (statPhones && navCountLeads) {
        new MutationObserver(function() {
          navCountLeads.textContent = statPhones.textContent;
        }).observe(statPhones, { childList: true, characterData: true, subtree: true });
      }

      // Mirror group name to top breadcrumb
      var groupLine = document.getElementById('zt-scan-group-line');
      var topTitle = document.getElementById('zt-top-context-title');
      if (groupLine && topTitle) {
        new MutationObserver(function() {
          if (groupLine.textContent && groupLine.textContent !== '—') {
            topTitle.textContent = groupLine.textContent;
          }
        }).observe(groupLine, { childList: true, characterData: true, subtree: true });
      }

      // Manage Floating Multi-Select Action Dock
      var tableBody = document.getElementById('zt-tbody');
      var floatingDock = document.getElementById('zt-floating-dock');
      var dockCount = document.getElementById('zt-dock-count');
      var selectAll = document.getElementById('zt-select-all');

      function updateDock() {
        if (!tableBody || !floatingDock) return;
        var checked = tableBody.querySelectorAll('input[type="checkbox"]:checked').length;
        if (checked > 0) {
          if (dockCount) dockCount.textContent = checked;
          floatingDock.classList.add('dock-visible');
        } else {
          floatingDock.classList.remove('dock-visible');
        }
      }

      if (tableBody) {
        tableBody.addEventListener('change', updateDock);
        tableBody.addEventListener('click', function(e) {
          if (e.target && e.target.type === 'checkbox') setTimeout(updateDock, 10);
        });
      }
      if (selectAll) {
        selectAll.addEventListener('change', function() {
          setTimeout(updateDock, 50);
        });
        selectAll.addEventListener('click', function() {
          setTimeout(updateDock, 50);
        });
      }

      // Mirror Live Status to Navigation Rail
      var statusPhase = document.getElementById('zt-status-phase');
      var liveText = document.getElementById('zt-live-status-text');
      var liveDot = document.getElementById('zt-live-dot');
      var liveBadge = document.getElementById('zt-badge-live-status');
      if (statusPhase && liveText) {
        new MutationObserver(function() {
          var txt = (statusPhase.textContent || '').trim();
          if (txt) {
            liveText.textContent = txt;
            if (txt.includes('Đã dừng') || txt.includes('kết thúc')) {
              if (liveDot) liveDot.className = 'h-1.5 w-1.5 rounded-full bg-rose-500';
              if (liveBadge) liveBadge.className = 'inline-flex items-center gap-1.5 rounded-full bg-rose-50 px-2.5 py-0.5 text-[11px] font-semibold text-rose-700 ring-1 ring-inset ring-rose-600/20';
            } else if (txt.includes('Tạm dừng')) {
              if (liveDot) liveDot.className = 'h-1.5 w-1.5 rounded-full bg-amber-500';
              if (liveBadge) liveBadge.className = 'inline-flex items-center gap-1.5 rounded-full bg-amber-50 px-2.5 py-0.5 text-[11px] font-semibold text-amber-700 ring-1 ring-inset ring-amber-600/20';
            } else {
              if (liveDot) liveDot.className = 'h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse';
              if (liveBadge) liveBadge.className = 'inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-2.5 py-0.5 text-[11px] font-semibold text-emerald-700 ring-1 ring-inset ring-emerald-600/20';
            }
          }
        }).observe(statusPhase, { childList: true, characterData: true, subtree: true });
      }
    });
  