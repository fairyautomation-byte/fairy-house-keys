/**
 * Tải tailwind.min.js rồi modal.js — tránh parse ~400KB JS đồng bộ trong <head>
 * (gây treo cả tab Facebook / “Page Unresponsive”).
 */
(function () {
  'use strict';

  function scriptUrl(rel) {
    try {
      return chrome.runtime.getURL(rel);
    } catch (e) {
      return rel;
    }
  }

  function appendScript(src, onload, onerror) {
    const s = document.createElement('script');
    s.src = src;
    s.async = false;
    if (onload) s.onload = onload;
    if (onerror) s.onerror = onerror;
    (document.head || document.documentElement).appendChild(s);
  }

  function notifyReady() {
    try {
      window.parent.postMessage({ source: 'zt-modal', type: 'READY' }, '*');
    } catch (e) {
      /* ignore */
    }
  }

  function loadModalJs() {
    appendScript(
      scriptUrl('src/ui/modal.js'),
      function () {
        notifyReady();
      },
      function () {
        notifyReady();
      }
    );
  }

  appendScript(
    scriptUrl('src/ui/tailwind.min.js'),
    function () {
      loadModalJs();
    },
    function () {
      loadModalJs();
    }
  );
})();
