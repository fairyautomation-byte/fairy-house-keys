/* global chrome */
(function () {
  'use strict';



  function $(id) {
    return document.getElementById(id);
  }

  function show(el, on, useFlex) {
    if (!el) return;
    el.classList.toggle('hidden', !on);
    if (useFlex) {
      if (on) el.classList.add('flex');
      else el.classList.remove('flex');
    }
  }

  function setLoading(v) {
    show($('zt-loading'), v, false);
  }

  function setLoginPanel(v) {
    show($('zt-panel-login'), v, true);
  }

  function setLoggedPanel(v) {
    show($('zt-panel-logged'), v, true);
  }

  function showLoginError(msg) {
    var p = $('zt-login-error');
    if (!p) return;
    if (!msg) {
      p.classList.add('hidden');
      p.textContent = '';
      return;
    }
    p.textContent = msg;
    p.classList.remove('hidden');
  }

  function send(action, payload) {
    return new Promise(function (resolve, reject) {
      try {
        chrome.runtime.sendMessage(
          Object.assign({ action: action }, payload || {}),
          function (resp) {
            if (chrome.runtime.lastError) {
              reject(new Error(chrome.runtime.lastError.message));
              return;
            }
            resolve(resp);
          }
        );
      } catch (e) {
        reject(e);
      }
    });
  }

  function refreshSession() {
    setLoading(true);
    setLoginPanel(false);
    setLoggedPanel(false);
    send('ZT_SERVER_SESSION_GET', {})
      .then(function (r) {
        setLoading(false);
        if (r && r.ok && r.authed) {
          var license = r.license || 'Unknown';
          $('zt-logged-email').textContent = license;

          var details = r.details || {};
          
          var planName = String(details.plan || details.plan_id || 'trial').toUpperCase();
          $('zt-license-plan').textContent = planName;

          var expireText = 'Không giới hạn';
          if (details.expires_at) {
            var ms = 0;
            if (typeof details.expires_at === 'string' || typeof details.expires_at === 'number') {
              ms = new Date(details.expires_at).getTime();
            } else if (details.expires_at._seconds) {
              ms = details.expires_at._seconds * 1000;
            } else if (details.expires_at.seconds) {
              ms = details.expires_at.seconds * 1000;
            }
            if (ms > 0) {
              var exDate = new Date(ms);
              expireText = exDate.toLocaleDateString('vi-VN');
            }
          }
          $('zt-license-expire').textContent = expireText;

          var limit = details.daily_limit;
          var used = details.daily_used || 0;
          var limitText = (limit === -1 || limit === null) ? '∞' : limit;
          $('zt-license-quota-text').textContent = used + ' / ' + limitText;

          var percent = 0;
          if (limit > 0) {
            percent = Math.min(100, Math.round((used / limit) * 100));
          }
          $('zt-license-quota-bar').style.width = percent + '%';

          $('zt-license-total-scans').textContent = 'Đã quét tổng cộng: ' + (details.total_scans || 0) + ' UID';

          setLoggedPanel(true);
          refreshFacebookStatus();
        } else {
          setLoginPanel(true);
        }
      })
      .catch(function () {
        setLoading(false);
        setLoginPanel(true);
      });
  }

  function setFacebookStatus(ready, msg, fbUid) {
    var dot = $('zt-fb-status-dot');
    var title = $('zt-fb-status-title');
    var desc = $('zt-fb-status-desc');
    if (!dot || !title || !desc) return;
    if (ready) {
      dot.classList.remove('bg-rose-400');
      dot.classList.add('bg-emerald-400');
      title.classList.remove('text-rose-200');
      title.classList.add('text-emerald-200');
      title.textContent = 'Dịch vụ sẵn sàng';
    } else {
      dot.classList.remove('bg-emerald-400');
      dot.classList.add('bg-rose-400');
      title.classList.remove('text-emerald-200');
      title.classList.add('text-rose-200');
      title.textContent = 'Dịch vụ chưa sẵn sàng';
    }
    desc.textContent = msg || (ready ? 'Dịch vụ đã sẵn sàng.' : 'Chưa sẵn sàng.');
  }

  function refreshFacebookStatus() {
    send('ZT_FB_ACCOUNT_STATUS', {})
      .then(function (r) {
        setFacebookStatus(!!(r && r.ready), (r && r.message) || '', (r && r.fbUid) || '');
      })
      .catch(function () {
        setFacebookStatus(false, 'Không kiểm tra được trạng thái nick Facebook hiện tại.', '');
      });
  }

  document.addEventListener('DOMContentLoaded', function () {
    refreshSession();

    $('zt-form-login').addEventListener('submit', function (ev) {
      ev.preventDefault();
      showLoginError('');
      var licenseKey = ($('zt-license-key').value || '').trim().toUpperCase();
      if (!licenseKey) return;
      var btn = $('zt-btn-submit');
      var label = $('zt-btn-submit-label');
      btn.disabled = true;
      label.textContent = 'Đang kích hoạt…';
      send('ZT_SERVER_LOGIN', { licenseKey: licenseKey })
        .then(function (r) {
          if (r && r.ok) {
            $('zt-license-key').value = '';
            refreshSession();
            chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
              if (tabs && tabs[0] && tabs[0].url && tabs[0].url.includes('facebook.com')) {
                chrome.tabs.reload(tabs[0].id);
              }
            });
          } else {
            showLoginError((r && r.error) || 'License Key không hợp lệ.');
          }
        })
        .catch(function (e) {
          showLoginError(e.message || 'Lỗi kết nối.');
        })
        .finally(function () {
          btn.disabled = false;
          label.textContent = 'Kích hoạt License';
        });
    });

    var btnLogout = $('zt-btn-logout');
    if (btnLogout) {
      btnLogout.addEventListener('click', function () {
        setLoading(true);
        send('ZT_SERVER_LOGOUT', {})
          .then(function() {
            refreshSession();
            chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
              if (tabs && tabs[0] && tabs[0].url && tabs[0].url.includes('facebook.com')) {
                chrome.tabs.reload(tabs[0].id);
              }
            });
          })
          .catch(refreshSession);
      });
    }

    $('zt-btn-refresh-status').addEventListener('click', function () {
      try {
        chrome.tabs.create({ url: 'https://fairy-house-keys.vercel.app', active: true });
      } catch (_) {
        /* ignore */
      }
    });

    $('zt-btn-register').addEventListener('click', function () {
      try {
        chrome.tabs.create({ url: 'https://fairy-house-keys.vercel.app/', active: true });
      } catch (_) {
        /* ignore */
      }
    });
  });
})();
