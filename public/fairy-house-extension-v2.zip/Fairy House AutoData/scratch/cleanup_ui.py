
import sys

def main():
    path = r'e:\Target\zoo-target-pro\src\ui\action-popup.html'
    with open(path, 'r', encoding='utf-8') as f:
        lines = f.readlines()
    
    # Remove lines containing 'zt-btn-logout' and the block around it
    # Looking at the file, it's roughly lines 114-123.
    # We already removed part of it.
    
    new_lines = []
    skip = False
    for line in lines:
        if 'id="zt-btn-logout"' in line:
            skip = True
            continue
        # If we already removed the ID line, we need to find where the button ended
        if skip:
            if '</button>' in line:
                skip = False
            continue
        # Also handle the case where we already messed up the button tag
        if 'class="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-rose-400/35' in line and not skip:
            skip = True
            continue
        
        new_lines.append(line)
        
    with open(path, 'w', encoding='utf-8') as f:
        f.writelines(new_lines)
    print("Done")

if __name__ == "__main__":
    main()
