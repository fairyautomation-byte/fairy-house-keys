/* global chrome */
/**
 * Phiên đăng nhập Zoo Target server (Sanctum) — dùng chung cho content scripts.
 * Token lưu tại chrome.storage.local; đồng bộ qua chrome.storage.onChanged.
 */
(function () {
  'use strict';

  var TOKEN_KEY = 'ztServerToken';
  var USER_KEY = 'ztServerUser';
  var SAVED_AT_KEY = 'ztServerTokenSavedAt';

  function hasToken(obj) {
    var t = obj && obj[TOKEN_KEY];
    return !!(t && String(t).trim());
  }

  function getVietnamToday() {
    try {
      return new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Ho_Chi_Minh' });
    } catch (_) {
      return new Date().toISOString().slice(0, 10);
    }
  }

  function getSessionFromStorage(cb) {
    if (typeof chrome === 'undefined' || !chrome.storage) {
      cb({ authed: false, token: null, user: null });
      return;
    }
    chrome.storage.local.get([TOKEN_KEY, USER_KEY, SAVED_AT_KEY, 'ztServerLicenseDetails'], function (d) {
      const token = d[TOKEN_KEY];
      const details = d['ztServerLicenseDetails'];
      // Nếu có token và details chưa hết hạn/chưa bị thu hồi thì xem như authed = true
      const authed = !!(token && (!details || details.license_status === 'ACTIVE'));
      
      const today = getVietnamToday();
      let dailyUsed = 0;
      if (details) {
        if (details.last_reset_date && details.last_reset_date !== today) {
          dailyUsed = 0;
        } else {
          dailyUsed = Number(details.daily_used) || 0;
        }
      }

      let hasQuota = true;
      if (details && typeof details.daily_limit !== 'undefined' && details.daily_limit !== -1 && details.daily_limit !== null) {
        if (dailyUsed >= details.daily_limit) {
          hasQuota = false;
        }
      }
      
      cb({
        authed: authed,
        hasQuota: hasQuota,
        token: token || null,
        user: d[USER_KEY] || null,
        savedAt: d[SAVED_AT_KEY] || null,
        details: details || null
      });
    });
  }

  /**
   * Gọi callback ngay với trạng thái hiện tại, sau đó mỗi khi token/user đổi.
   * @param {function({authed:boolean,token:string,user:*,savedAt:*}):void} cb
   */
  function subscribe(cb) {
    getSessionFromStorage(cb);
    try {
      chrome.storage.onChanged.addListener(function (changes, area) {
        if (area !== 'local') return;
        if (!changes[TOKEN_KEY] && !changes[USER_KEY] && !changes[SAVED_AT_KEY] && !changes['ztServerLicenseDetails']) return;
        getSessionFromStorage(cb);
      });
    } catch (_) {
      /* ignore */
    }
  }

  /**
   * Chỉ chạy fn khi đã có token; khi mất token gọi onRevoke (nếu có).
   * @param {function():void} fn
   * @param {function():void} [onRevoke]
   */
  function whenAuthed(fn, onRevoke) {
    var started = false;
    subscribe(function (s) {
      // Chỉ revoke quyền gọi bridge khi mất token (authed = false). 
      // Hết quota (hasQuota = false) thì vẫn giữ bridge để modal đang mở không bị văng.
      if (s.authed) {
        if (!started) {
          started = true;
          try {
            fn();
          } catch (e) {
            console.warn('[ZT] whenAuthed', e);
          }
        }
      } else {
        if (started) {
          started = false;
          if (typeof onRevoke === 'function') {
            try {
              onRevoke();
            } catch (e2) {
              console.warn('[ZT] onRevoke', e2);
            }
          }
        }
      }
    });
  }

  window.ZTServerSession = {
    TOKEN_KEY: TOKEN_KEY,
    USER_KEY: USER_KEY,
    SAVED_AT_KEY: SAVED_AT_KEY,
    getSessionFromStorage: getSessionFromStorage,
    subscribe: subscribe,
    whenAuthed: whenAuthed,
    hasToken: hasToken
  };
})();
