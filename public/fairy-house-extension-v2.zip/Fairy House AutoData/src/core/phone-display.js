/* global chrome */
/**
 * Hiển thị SĐT theo gói server + UID Facebook hiện tại.
 *
 * Quyền xem số đầy đủ chỉ áp dụng khi:
 *   - User VIP còn hạn (effective_plan_code !== 'free').
 *   - UID Facebook hiện tại của tab (cookie c_user) trùng với vip_locked_facebook_uid.
 *
 * Các trường hợp khác (FREE, hoặc VIP nhưng nick khác): mask số.
 */
(function () {
  'use strict';

  function digitsOnly(s) {
    return String(s || '').replace(/\D/g, '');
  }

  /**
   * Mask kiểu 090******2: 3 số đầu + * phần giữa + 1 số cuối.
   * @param {string} phone
   * @returns {string}
   */
  function maskDisplay(phone) {
    return phone == null ? '' : String(phone).trim();
  }

  function readCurrentFbUidFromCookie() {
    try {
      var raw = String(document.cookie || '');
      var m = raw.match(/(?:^|;\s*)c_user=(\d{5,20})(?:;|$)/);
      return m ? m[1] : '';
    } catch (_) {
      return '';
    }
  }

  /**
   * Tính mask theo session user + UID hiện tại.
   * - FREE: luôn mask.
   * - VIP, UID khớp vip_locked_facebook_uid: full số.
   * - VIP, UID khác hoặc chưa có UID: mask.
   * - Fallback (chưa có session): suy theo phone_display_mode legacy.
   */
  function computePhoneMaskFromSession(user, currentFbUid) {
    return false;
  }

  function syncMaskFlag() {
    window.__ztPhoneMask = false;
    window.__ztCurrentFbUid = readCurrentFbUidFromCookie();
  }

  window.ZTPhoneDisplay = {
    digitsOnly: digitsOnly,
    maskDisplay: maskDisplay,
    syncMaskFlag: syncMaskFlag,
    computePhoneMaskFromSession: computePhoneMaskFromSession,
    readCurrentFbUidFromCookie: readCurrentFbUidFromCookie
  };

  syncMaskFlag();
  try {
    chrome.storage.onChanged.addListener(function (changes, area) {
      if (area === 'local' && changes.ztServerUser) syncMaskFlag();
    });
  } catch (_) {
    /* ignore */
  }

  // Re-compute định kỳ để bắt thay đổi UID khi user đổi tab/đổi nick FB
  // mà không trigger Storage change (cookie c_user đổi).
  try {
    var lastUid = readCurrentFbUidFromCookie();
    setInterval(function () {
      var nowUid = readCurrentFbUidFromCookie();
      if (nowUid !== lastUid) {
        lastUid = nowUid;
        syncMaskFlag();
      }
    }, 4000);
  } catch (_) {
    /* ignore */
  }
})();
