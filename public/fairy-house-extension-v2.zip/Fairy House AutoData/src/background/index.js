/* global chrome */

chrome.runtime.onInstalled.addListener(() => {
  console.log('[Zoo Target] installed');
});

function detectTokenKind(token) {
  const t = (token || '').trim();
  if (t.startsWith('EAAG')) return 'EAAG';
  if (t.startsWith('EAAB')) return 'EAAB';
  return 'UNKNOWN';
}

function extractTokenByPrefix(html, prefix) {
  if (!html) return null;
  const re = new RegExp('(' + prefix + '[0-9A-Za-z]+)', 'g');
  const m = re.exec(html);
  return m && m[1] ? m[1] : null;
}

async function fetchBusinessEAAGToken() {
  try {
    await fetch('https://business.facebook.com/', { method: 'GET', credentials: 'include', redirect: 'follow' });
  } catch (_) { /* ignore */ }

  const resp = await fetch('https://business.facebook.com/content_management/?nav_source=flyout_menu', {
    method: 'GET',
    credentials: 'include',
    redirect: 'follow'
  });
  if (!resp.ok) throw new Error('HTTP ' + resp.status);
  const text = await resp.text();
  const eaag = extractTokenByPrefix(text, 'EAAG');
  if (!eaag) throw new Error('NO_EAAG');
  return eaag.trim();
}

async function getAdsAccessToken() {
  const tabs = await chrome.tabs.query({ url: '*://adsmanager.facebook.com/*' });
  for (const tab of tabs) {
    if (!tab.id) continue;
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: function () {
          return (typeof window._accessToken === 'string' && window._accessToken)
            ? window._accessToken
            : (typeof window.__accessToken === 'string' && window.__accessToken)
              ? window.__accessToken
              : null;
        }
      });
      const token = results?.[0]?.result;
      if (token && typeof token === 'string' && token.trim()) {
        const t = token.trim();
        try {
          await chrome.storage.local.set({ adsAccessToken: t, adsAccessTokenKind: detectTokenKind(t) });
        } catch (_) { /* ignore */ }
        return { token: t, kind: detectTokenKind(t) };
      }
    } catch (_) { /* ignore tab */ }
  }

  const resp = await fetch('https://adsmanager.facebook.com/adsmanager/', {
    method: 'GET',
    credentials: 'include',
    redirect: 'follow'
  });
  if (!resp.ok) throw new Error('HTTP ' + resp.status);
  const text = await resp.text();

  let token = extractTokenByPrefix(text, 'EAAB');
  if (!token) token = extractTokenByPrefix(text, 'EAAG');
  if (!token) {
    try {
      const eaag = await fetchBusinessEAAGToken();
      await chrome.storage.local.set({ adsAccessToken: eaag, adsAccessTokenKind: 'EAAG' });
      return { token: eaag, kind: 'EAAG' };
    } catch (_) {
      throw new Error('ADS_VERIFY_REQUIRED');
    }
  }
  token = token.replace(/\\"/g, '"').trim();
  try {
    await chrome.storage.local.set({ adsAccessToken: token, adsAccessTokenKind: detectTokenKind(token) });
  } catch (_) { /* ignore */ }
  return { token, kind: detectTokenKind(token) };
}

async function getGenderMap(uids, token) {
  const out = {};
  /** Mỗi vòng tối đa 50 `ids` (URL an toàn; batch modal 100 UID → 2 vòng Graph). */
  const chunkSize = 50;
  const list = uids.map((u) => String(u));
  for (let i = 0; i < list.length; i += chunkSize) {
    const chunk = list.slice(i, i + chunkSize);
    const ids = chunk.join(',');
    const url = 'https://graph.facebook.com/v21.0/?ids=' + encodeURIComponent(ids)
      + '&fields=id,name,gender,picture.width(80).height(80)&access_token=' + encodeURIComponent(token);
    const r = await fetch(url);
    const j = await r.json().catch(() => ({}));
    if (j.error) throw new Error(j.error.message || 'Graph API lỗi');
    for (const id of chunk) {
      const row = j[id];
      if (row) {
        out[id] = {
          name: row.name || '',
          gender: row.gender || '',
          pictureUrl: row.picture?.data?.url || ''
        };
      }
    }
  }
  return out;
}

function sleepBg(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

/**
 * Graph REST — danh sách bài Fanpage (token EAAB từ Ads Manager).
 * @param {string} pageId
 * @param {string} nextUrl - paging.next đầy đủ hoặc rỗng
 * @param {number} retryCount
 */
async function fanpageFetchPostsPage(pageId, nextUrl, retryCount) {
  const rc = retryCount || 0;
  const tokResult = await getAdsAccessToken();
  const tok = tokResult && tokResult.token ? String(tokResult.token).trim() : '';
  if (!tok) {
    return { ok: false, error: 'Không có access token', posts: [], nextUrl: null };
  }
  const base = 'https://graph.facebook.com/v21.0/';
  const fields = 'id,created_time,message';
  const url =
    nextUrl && String(nextUrl).trim()
      ? String(nextUrl).trim()
      : base +
        encodeURIComponent(String(pageId)) +
        '/posts?fields=' +
        encodeURIComponent(fields) +
        '&limit=50&access_token=' +
        encodeURIComponent(tok);
  const r = await fetch(url);
  const j = await r.json().catch(() => ({}));
  if (j.error) {
    const code = Number(j.error.code || 0);
    if ((code === 4 || code === 17 || code === 32 || code === 613 || code === 800) && rc < 3) {
      await sleepBg(30000);
      return fanpageFetchPostsPage(pageId, nextUrl, rc + 1);
    }
    return {
      ok: false,
      error: j.error.message || String(code),
      posts: [],
      nextUrl: null
    };
  }
  const rawList = j.data || [];
  const posts = rawList.map((p) => {
    const full = String(p.id || '');
    const mm = full.match(/_(\d+)$/);
    const postId = mm ? mm[1] : full.replace(/\D/g, '') || full;
    return {
      postId: String(postId),
      fullId: full,
      created_time: p.created_time || '',
      message: p.message || ''
    };
  });
  return {
    ok: true,
    posts,
    nextUrl: j.paging && j.paging.next ? j.paging.next : null
  };
}

/**
 * Gộp kết quả phone.zooinbox.com — API đôi khi trả `phones` dù không có `ok`,
 * hoặc tên field khác (mobile, PhoneNumber, user_id).
 */
function mergePhoneApiPayloadIntoMap(map, d, requestedUids) {
  if (!d || typeof d !== 'object') return;
  const rows = Array.isArray(d.phones)
    ? d.phones
    : Array.isArray(d.data)
      ? d.data
      : Array.isArray(d.rows)
        ? d.rows
        : Array.isArray(d.result)
          ? d.result
          : null;
  if (rows) {
    for (let i = 0; i < rows.length; i++) {
      const p = rows[i];
      if (!p || typeof p !== 'object') continue;
      const uidRaw = p.uid != null ? p.uid : p.UID != null ? p.UID : p.user_id != null ? p.user_id : p.fb_id != null ? p.fb_id : p.id;
      if (uidRaw == null) continue;
      const uid = String(uidRaw).replace(/\D/g, '');
      if (!/^\d{5,20}$/.test(uid)) continue;
      const ph =
        p.phone != null
          ? p.phone
          : p.Phone != null
            ? p.Phone
            : p.mobile != null
              ? p.mobile
              : p.tel != null
                ? p.tel
                : p.PhoneNumber != null
                  ? p.PhoneNumber
                  : '';
      const ps = String(ph).trim();
      if (!ps || /^phone\s*number$/i.test(ps)) continue;
      map[uid] = ps;
    }
  }
  if (d.map && typeof d.map === 'object') {
    const keys = Object.keys(d.map);
    for (let j = 0; j < keys.length; j++) {
      const k = keys[j];
      const v = d.map[k];
      const uid = String(k).replace(/\D/g, '');
      if (!/^\d{5,20}$/.test(uid)) continue;
      const ps = v != null ? String(v).trim() : '';
      if (ps && !/^phone\s*number$/i.test(ps)) map[uid] = ps;
    }
  }
  for (let r = 0; r < requestedUids.length; r++) {
    const u = String(requestedUids[r]);
    if (d[u] != null) {
      const ps = String(d[u]).trim();
      if (ps && !/^phone\s*number$/i.test(ps)) map[u.replace(/\D/g, '')] = ps;
    }
  }
  const dk = Object.keys(d);
  for (let x = 0; x < dk.length; x++) {
    const k = dk[x];
    const kn = String(k).replace(/\D/g, '');
    if (!/^\d{10,20}$/.test(kn)) continue;
    const v = d[k];
    const ps = v != null ? String(v).trim() : '';
    if (ps && !/^phone\s*number$/i.test(ps)) map[kn] = ps;
  }
}

function alignPhoneMapKeysToRequested(map, requestedUids) {
  const out = {};
  const req = requestedUids.map((u) => String(u).replace(/\D/g, ''));
  for (let i = 0; i < req.length; i++) {
    const want = req[i];
    if (!want) continue;
    if (map[want]) {
      out[requestedUids[i]] = map[want];
      continue;
    }
    const keys = Object.keys(map);
    for (let k = 0; k < keys.length; k++) {
      const key = keys[k];
      if (String(key).replace(/\D/g, '') === want) {
        out[requestedUids[i]] = map[key];
        break;
      }
    }
  }
  return out;
}

function getVietnamToday() {
  try {
    return new Date().toLocaleDateString('en-CA', { timeZone: 'Asia/Ho_Chi_Minh' });
  } catch (_) {
    return new Date().toISOString().slice(0, 10);
  }
}

async function getPhoneMap(uids) {
  const d = await chrome.storage.local.get(['ztServerToken', 'ztServerLicenseDetails']);
  if (!d.ztServerToken) {
    throw new Error('Vui lòng nhập License Key để sử dụng.');
  }
  
  let scanRes;
  for (let retry = 0; retry < 3; retry++) {
    try {
      scanRes = await fetch(ZT_API_BASE + '/api/license/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ licenseKey: d.ztServerToken, action: 'consume', count: uids.length })
      });
      if (scanRes.status !== 429) break;
      await sleepBg(1200 * (retry + 1));
    } catch (netErr) {
      if (retry === 2) throw netErr;
      await sleepBg(1000);
    }
  }
  
  const scanData = await scanRes.json().catch(() => ({}));
  if (!scanData.success) {
    if (scanData.code === 'DAILY_LIMIT_REACHED') {
      throw new Error('License Key của bạn đã hết lượt Quota hôm nay.');
    } else if (scanData.code === 'RATE_LIMIT_EXCEEDED') {
      throw new Error('Hệ thống đang bận do quét quá nhanh. Vui lòng chờ vài giây rồi tiếp tục.');
    } else {
      throw new Error(scanData.error || 'License Key không hợp lệ hoặc đã hết hạn.');
    }
  }

  // Cập nhật quota mới nhất vào local storage kèm ngày reset
  const today = getVietnamToday();
  const prevDetails = d.ztServerLicenseDetails || {};
  const updatedDetails = {
    ...prevDetails,
    daily_used: scanData.daily_used != null ? scanData.daily_used : (prevDetails.daily_used || 0) + uids.length,
    daily_limit: scanData.daily_limit != null ? scanData.daily_limit : prevDetails.daily_limit,
    last_reset_date: scanData.last_reset_date || today,
    total_scans: (prevDetails.total_scans || 0) + uids.length,
    license_status: 'ACTIVE'
  };
  await chrome.storage.local.set({ ztServerLicenseDetails: updatedDetails });

  const list = uids.map((u) => String(u));
  const map = {};
  const body1 = JSON.stringify({ action: 'uids2phones', uids: list });
  const r1 = await fetch('https://phone.zooinbox.com/db1/', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: body1
  });
  const d1 = await r1.json().catch(() => ({}));
  mergePhoneApiPayloadIntoMap(map, d1, list);
  const missing = list.filter((u) => {
    const n = String(u).replace(/\D/g, '');
    return !map[n] && !map[u];
  });
  if (missing.length) {
    const r2 = await fetch('https://phone.zooinbox.com/db2/', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'uids2phones', uids: missing })
    });
    const d2 = await r2.json().catch(() => ({}));
    mergePhoneApiPayloadIntoMap(map, d2, missing);
  }
  const finalMap = alignPhoneMapKeysToRequested(map, list);
  return finalMap;
}

const ZT_API_BASE = 'https://fairyautomation.io.vn';
const ZT_DEVICE_NAME = 'tien-house-automation';

async function ztServerLoginFlow(licenseKey, isRefresh = false) {
  try {
    const r = await fetch(ZT_API_BASE + '/api/license/validate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ licenseKey })
    });
    
    // Nếu gặp lỗi rate limit (429) hoặc lỗi mạng 5xx từ server:
    if (r.status === 429 || r.status >= 500) {
      console.warn('[ZT Server] validate status:', r.status);
      const current = await chrome.storage.local.get(['ztServerLicenseDetails']);
      return { 
        ok: isRefresh, 
        license: licenseKey, 
        details: current.ztServerLicenseDetails || null,
        error: 'Máy chủ đang bận. Vui lòng thử lại sau.' 
      };
    }

    const d = await r.json().catch(() => ({}));
    
    if (!d.valid) {
      // Chỉ xóa token khi server xác nhận rõ ràng Key không tồn tại hoặc bị thu hồi (admin xóa)
      const isPermanent = d.error === 'LICENSE_NOT_FOUND' || d.error === 'LICENSE_REVOKED' || d.error === 'INVALID_LICENSE';
      if (isPermanent && (r.status === 404 || r.status === 403 || r.status === 400)) {
        await chrome.storage.local.remove(['ztServerToken', 'ztServerUser', 'ztServerTokenSavedAt', 'ztServerLicenseDetails']);
      } else if (d.error === 'LICENSE_EXPIRED') {
        const current = await chrome.storage.local.get(['ztServerLicenseDetails']);
        if (current.ztServerLicenseDetails) {
          current.ztServerLicenseDetails.license_status = 'EXPIRED';
          await chrome.storage.local.set({ ztServerLicenseDetails: current.ztServerLicenseDetails });
        }
      }
      return { ok: false, error: d.error || 'License Key không hợp lệ hoặc đã hết hạn.' };
    }
    
    // Fix Race Condition: Nếu đang refresh mà người dùng đã bấm Đổi Key (logout), thì không lưu lại token cũ.
    if (isRefresh) {
      const current = await chrome.storage.local.get(['ztServerToken']);
      if (current.ztServerToken && current.ztServerToken !== licenseKey) {
        return { ok: false, error: 'Token đã bị thay đổi trong lúc refresh' };
      }
    }

    const today = getVietnamToday();
    const finalDetails = {
      ...d,
      last_reset_date: d.last_reset_date || today
    };

    await chrome.storage.local.set({
      ztServerToken: licenseKey,
      ztServerUser: { email: licenseKey, name: 'User' },
      ztServerLicenseDetails: finalDetails,
      ztServerTokenSavedAt: Date.now()
    });
    return { ok: true, license: licenseKey, details: finalDetails };
  } catch (e) {
    console.warn('[ZT Server] LoginFlow network error:', e);
    // Khi mất mạng, TUYỆT ĐỐI KHÔNG XÓA KEY CỦA USER
    const current = await chrome.storage.local.get(['ztServerLicenseDetails']);
    return { 
      ok: isRefresh, 
      license: licenseKey, 
      details: current.ztServerLicenseDetails || null,
      error: e.message || 'Lỗi kết nối máy chủ' 
    };
  }
}

async function ztServerLogoutFlow() {
  await chrome.storage.local.remove(['ztServerToken', 'ztServerUser', 'ztServerTokenSavedAt', 'ztServerLicenseDetails']);
  return { ok: true };
}

let lastRefreshMeTimestamp = 0;
let lastRefreshMeResponse = null;

async function ztServerRefreshMeFlow(force = false) {
  const d = await chrome.storage.local.get(['ztServerToken', 'ztServerLicenseDetails']);
  if (!d.ztServerToken) return { ok: false, error: 'Chưa đăng nhập' };
  
  const now = Date.now();
  // Throttle: Không gửi request validate quá nhiều trong 15s nếu không force
  if (!force && lastRefreshMeResponse && (now - lastRefreshMeTimestamp < 15000)) {
    return lastRefreshMeResponse;
  }
  
  const res = await ztServerLoginFlow(d.ztServerToken, true);
  if (res && res.ok) {
    lastRefreshMeTimestamp = now;
    lastRefreshMeResponse = res;
  }
  return res;
}

async function ztGetFacebookAccountStatus() {
  let fbUid = '';
  try {
    const ck = (await chrome.cookies.get({ url: 'https://www.facebook.com', name: 'c_user' }))
      || (await chrome.cookies.get({ url: 'https://www.facebook.com', name: 'i_user' }));
    fbUid = ck && ck.value ? String(ck.value).replace(/\D/g, '') : '';
  } catch (_) {
    fbUid = '';
  }

  return {
    ok: true,
    ready: true,
    fbUid: fbUid,
    isVipActive: true,
    isVipLocked: true,
    message: 'Dịch vụ đã sẵn sàng.'
  };
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg?.action === 'ZT_SERVER_LOGIN') {
    ztServerLoginFlow(msg.licenseKey)
      .then((r) => sendResponse(r))
      .catch((e) => sendResponse({ ok: false, error: e.message || String(e) }));
    return true;
  }

  if (msg?.action === 'ZT_SERVER_LOGOUT') {
    ztServerLogoutFlow()
      .then((r) => sendResponse(r))
      .catch((e) => sendResponse({ ok: false, error: e.message || String(e) }));
    return true;
  }

  if (msg?.action === 'ZT_SERVER_SESSION_GET') {
    (async () => {
      const d = await chrome.storage.local.get(['ztServerToken', 'ztServerLicenseDetails']);
      if (d.ztServerToken) {
        let details = d.ztServerLicenseDetails;
        const today = getVietnamToday();
        
        // Tự động reset sang 0 nếu bước sang ngày mới theo giờ Việt Nam
        if (details) {
          if (details.last_reset_date && details.last_reset_date !== today) {
            details.daily_used = 0;
            details.last_reset_date = today;
            await chrome.storage.local.set({ ztServerLicenseDetails: details });
          }
        }
        
        let hasQuota = true;
        if (details && details.daily_limit !== -1 && details.daily_limit !== null && typeof details.daily_limit !== 'undefined') {
          if ((details.daily_used || 0) >= details.daily_limit) {
            hasQuota = false;
          }
        }
        
        sendResponse({
          ok: true,
          authed: true,
          hasQuota: hasQuota,
          license: d.ztServerToken,
          details: details || {
            plan: 'standard',
            daily_limit: 1000,
            daily_used: 0,
            license_status: 'ACTIVE',
            last_reset_date: today
          }
        });
      } else {
        sendResponse({ ok: false, authed: false });
      }
    })().catch((e) => sendResponse({ ok: false, error: e.message || String(e) }));
    return true;
  }

  if (msg?.action === 'ZT_FB_ACCOUNT_STATUS') {
    ztGetFacebookAccountStatus()
      .then((r) => sendResponse(r))
      .catch((e) =>
        sendResponse({
          ok: false,
          ready: false,
          fbUid: '',
          isVipActive: false,
          isVipLocked: false,
          message: e && e.message ? String(e.message) : 'Không kiểm tra được trạng thái Facebook.'
        })
      );
    return true;
  }

  if (msg?.action === 'CHROME_STORAGE_SET') {
    chrome.storage.local.set({ [msg.key]: msg.value }, () => {
      sendResponse({ ok: true });
    });
    return true;
  }

  if (msg?.action === 'CHROME_STORAGE_GET') {
    chrome.storage.local.get([msg.key], (res) => {
      sendResponse({ ok: true, value: res[msg.key] || null });
    });
    return true;
  }

  if (msg?.action === 'ZT_SERVER_REFRESH_ME') {
    ztServerRefreshMeFlow(!!msg.force)
      .then((r) => sendResponse(r))
      .catch((e) => sendResponse({ ok: false, error: e.message || String(e) }));
    return true;
  }

  if (msg?.action === 'ZT_SERVER_SYNC_FACEBOOK_PROFILE') {
    (async () => {
      sendResponse({ ok: true, data: { user: { email: 'admin@local', name: 'Admin', effective_plan_code: 'vip' } } });
    })().catch((e) => sendResponse({ ok: false, error: e.message || String(e) }));
    return true;
  }

  if (msg?.action === 'ZT_EXTENSION_SCAN_LOG') {
    (async () => {
      sendResponse({ ok: true });
    })().catch((e) => sendResponse({ ok: false, error: e.message || String(e) }));
    return true;
  }

  if (msg?.action === 'ZT_EXTENSION_UID_DEMO_BATCH') {
    (async () => {
      sendResponse({ ok: true, skipped: true });
    })().catch((e) => sendResponse({ ok: false, error: e.message || String(e) }));
    return true;
  }

  if (msg?.action === 'ZT_EXTENSION_FRIEND_INVITE_QUOTA') {
    (async () => {
      sendResponse({ ok: true, data: { allowed: true } });
    })().catch((e) => sendResponse({ ok: false, error: e.message || String(e) }));
    return true;
  }

  if (msg?.action === 'OPEN_ZT_UI') {
    (async () => {
      const fbTabId = sender.tab?.id;
      if (!fbTabId) {
        sendResponse({ ok: false, error: 'Không xác định được tab Facebook' });
        return;
      }
      let sourceTabUrl = '';
      try {
        const t = await chrome.tabs.get(fbTabId);
        if (t && t.url) {
          sourceTabUrl = String(t.url).split('#')[0];
        }
      } catch (_) {
        /* ignore */
      }
      const sk =
        'zt' +
        Date.now().toString(36) +
        Math.random()
          .toString(36)
          .replace(/[^a-z0-9]+/g, '')
          .slice(0, 10);
      await chrome.storage.session.set({
        [sk]: {
          kind: msg.kind === 'profile' ? 'profile' : 'group',
          profileId: String(msg.profileId || ''),
          groupId: String(msg.groupId || ''),
          groupName: String(msg.groupName || ''),
          fbTabId,
          sourceTabUrl,
        }
      });
      const url = chrome.runtime.getURL('src/ui/modal.html') + '?zt=' + encodeURIComponent(sk);
      await chrome.tabs.create({ url, active: true });
      sendResponse({ ok: true });
    })().catch((e) => sendResponse({ ok: false, error: e.message || String(e) }));
    return true;
  }

  if (msg?.action === 'ZT_BRIDGE') {
    const fbTabId = msg.fbTabId;
    const bridgeAction = msg.bridgeAction;
    const payload = msg.payload || {};
    if (typeof fbTabId !== 'number' || !bridgeAction) {
      sendResponse({ ok: false, error: 'Thiếu fbTabId hoặc bridgeAction' });
      return true;
    }
    chrome.tabs.get(fbTabId, (tab) => {
      if (chrome.runtime.lastError || !tab) {
        sendResponse({
          ok: false,
          error: 'Tab Facebook đã đóng hoặc không còn hợp lệ — quay lại tab profile/nhóm rồi mở Fairy House AutoData lại.'
        });
        return;
      }
      chrome.tabs.sendMessage(
        fbTabId,
        {
          type: 'ZT_BRIDGE',
          action: bridgeAction,
          payload
        },
        (resp) => {
          if (chrome.runtime.lastError) {
            sendResponse({ ok: false, error: chrome.runtime.lastError.message });
            return;
          }
          if (resp?.ok) {
            sendResponse({ ok: true, data: resp.data });
          } else {
            sendResponse({ ok: false, error: resp?.error || 'Lỗi bridge' });
          }
        }
      );
    });
    return true;
  }

  if (msg?.action === 'graphGetNameById') {
    (async () => {
      const id = String(msg.id || '').trim();
      const token = String(msg.token || '').trim();
      if (!id || !token) {
        sendResponse({ ok: false, error: 'Thiếu id hoặc token' });
        return;
      }
      const url =
        'https://graph.facebook.com/v21.0/' +
        encodeURIComponent(id) +
        '?fields=name,picture.width(120).height(120)&access_token=' +
        encodeURIComponent(token);
      try {
        const resp = await fetch(url);
        const j = await resp.json().catch(() => ({}));
        if (!resp.ok || j.error) {
          sendResponse({ ok: true, name: '', pictureUrl: '' });
          return;
        }
        sendResponse({
          ok: true,
          name: j.name ? String(j.name) : '',
          pictureUrl: j.picture && j.picture.data && j.picture.data.url ? String(j.picture.data.url) : ''
        });
      } catch (_) {
        sendResponse({ ok: true, name: '', pictureUrl: '' });
      }
    })();
    return true;
  }

  if (msg?.action === 'fanpageFetchPostsPage') {
    (async () => {
      try {
        await sleepBg(180 + Math.floor(Math.random() * 80));
        const pageId = String(msg.pageId || '').trim();
        const nextUrl = msg.nextUrl != null ? String(msg.nextUrl) : '';
        if (!pageId && !nextUrl) {
          sendResponse({ ok: false, error: 'Thiếu pageId', posts: [], nextUrl: null });
          return;
        }
        const out = await fanpageFetchPostsPage(pageId || '0', nextUrl, 0);
        sendResponse(out);
      } catch (e) {
        sendResponse({ ok: false, error: e.message || String(e), posts: [], nextUrl: null });
      }
    })();
    return true;
  }

  if (msg?.action === 'getAdsAccessToken') {
    getAdsAccessToken()
      .then((result) => sendResponse({ ok: true, token: result?.token || null, kind: result?.kind || null }))
      .catch((e) => sendResponse({ ok: false, error: e.message || 'Lỗi lấy token Ads Manager' }));
    return true;
  }

  if (msg?.action === 'getPhoneMapOnly') {
    (async () => {
      const uids = msg.uids;
      if (!Array.isArray(uids) || !uids.length) {
        sendResponse({ ok: false, error: 'Thiếu uids' });
        return;
      }
      try {
        const phoneMap = await getPhoneMap(uids.map((u) => String(u)));
        sendResponse({ ok: true, phoneMap });
      } catch (e) {
        sendResponse({ ok: false, error: e.message || String(e) });
      }
    })();
    return true;
  }

  if (msg?.action === 'enrichBatch') {
    (async () => {
      const uids = msg.uids;
      const token = msg.token;
      if (!Array.isArray(uids) || !uids.length) {
        sendResponse({ ok: false, error: 'Thiếu uids' });
        return;
      }
      if (!token || !String(token).trim()) {
        sendResponse({ ok: false, error: 'Thiếu access token' });
        return;
      }
      const [genderMap, phoneMap] = await Promise.all([
        getGenderMap(uids, String(token).trim()),
        getPhoneMap(uids)
      ]);
      sendResponse({ ok: true, data: { genderMap, phoneMap } });
    })().catch((e) => sendResponse({ ok: false, error: e.message || 'enrichBatch lỗi' }));
    return true;
  }
  return false;
});
