# KẾ HOẠCH FULL UI/UX REBUILD — THAY ĐỔI TOÀN BỘ KIẾN TRÚC BỐ CỤC
## DỰ ÁN: FAIRY HOUSE AUTODATA V2.0 (CHROME EXTENSION)

> **Mục tiêu tối thượng:** Xóa bỏ hoàn toàn tư duy bố cục cũ (không redesign bề mặt, không làm mới kiểu đổi màu đổi font). Xây dựng một **Information Architecture mới** theo chuẩn **UI/UX Skill** với phong cách **Enterprise SaaS Workstation**, trong khi **bảo toàn 100% chức năng và business logic hiện có**.

---

## 1. AUDIT HỆ THỐNG & ĐỐI CHIẾU UI/UX SKILL

### 1.1. Dòng Audit kỹ thuật (Câu 2 UI/UX Skill)
> **Audit:** Chrome Extension Manifest V3 (Vanilla JS, Tailwind CSS runtime, CSS Custom Properties). Đã có logic lõi trong `src/ui/modal.js` (quản lý 118 DOM IDs), `src/ui/action-popup.js`, backend GraphQL Facebook & Firebase Auth qua `src/core/auth.js`. Phong cách: Flat SaaS Workstation, màu chủ đạo Teal (`#0d9488`), nền Surface (`#ffffff` / `#f8f9fa`).

### 1.2. U1. Brief dự án
* **Sản phẩm:** Fairy House AutoData V2.0 — Extension tự động hóa khai thác dữ liệu khách hàng tiềm năng Facebook (Group, Fanpage, Profile), bóc tách số điện thoại, phân tích nhân khẩu học và hỗ trợ tự động kết bạn (Auto Invite).
* **Đối tượng người dùng:** Marketer, Telesales, Chủ shop bán hàng online, Nhà quảng cáo Facebook Ads.
* **1 – 3 Việc chính:**
  1. *Xác thực bản quyền & quản lý hạn mức:* Kích hoạt License Key, theo dõi số lượt quét còn lại trong ngày.
  2. *Khai thác data mục tiêu:* Quét thành viên, tự động giải mã SĐT thời gian thực, lọc nhanh theo giới tính, đầu số, tỉnh/thành.
  3. *Hành động chuyển đổi:* Chọn danh sách khách hàng để gửi lời mời kết bạn tự động và xuất file Excel (.xlsx) / UID (.txt).
* **Nền tảng sử dụng:** Môi trường Desktop Web trên Google Chrome (laptop 1366×768 đến màn hình lớn Full HD / 2K).
* **Điểm khác biệt:** Tốc độ quét và hiển thị SĐT thời gian thực, kết hợp phân tích đối tượng ngay trên nền Facebook.

### 1.3. U2. Việc chính của từng màn hình

| Màn hình | Đến để làm gì? | So sánh, quyết định bằng gì? | Hành động cuối cùng | Loại sản phẩm này thường làm |
| :--- | :--- | :--- | :--- | :--- |
| **Popup Extension** (`action-popup.html`) | Kiểm tra bản quyền, theo dõi quota quét hôm nay, kích hoạt key mới. | Số lượt còn lại (Hero Quota), hạn dùng gói, trạng thái hợp lệ. | Bấm "Mở Facebook để quét" hoặc "Đổi Key". | Popup chuẩn 380px, thẻ Quota tiến độ rõ ràng, CTA mở Facebook. |
| **Workstation Modal** (`modal.html`) | Thiết lập chiến dịch, theo dõi tiến độ quét SĐT realtime, lọc danh sách, phân tích tệp và auto kết bạn. | Tỷ lệ ra SĐT (%), chất lượng đầu số (09x cổ vs 03x mới), khu vực địa phương, điểm tiềm năng. | Xuất file Excel hoặc bấm "Auto Kết bạn" cho tệp khách đã chọn. | Enterprise SaaS Workstation (App Shell): Cột điều hướng Left Rail, thanh lệnh Top Command Bar, bảng full-width và dock thao tác nổi. |

---

## 2. NGUYÊN TẮC: GIỮ "WHAT", BỎ TOÀN BỘ "HOW"

Để tránh bẫy "bình mới rượu cũ", toàn bộ các thành phần layout cũ bị loại bỏ và thay thế bằng tư duy mới:

| Thành phần cũ (BỎ HOÀN TOÀN) | Bản chất chức năng (GIỮ NGUYÊN "WHAT") | Giải pháp kiến trúc mới (HOW MỚI) |
| :--- | :--- | :--- |
| **Khung popup modal nhỏ hẹp** | Không gian thao tác nghiệp vụ khai thác dữ liệu | **Workstation Viewport (1440px × 92vh)** cố định, không giật kích thước |
| **Header cũ nhồi nhét stat pills** | Đo lường hiệu suất quét (UID, SĐT, Tiến độ) | **SaaS KPI Metric Row** độc lập với thẻ Hero Teal nổi bật |
| **Sidebar 260px ép chật bảng** | Phân tích nhân khẩu học (Giới tính, Nhà mạng, Vùng) | **Expansive Analytics Dashboard** chuyển đổi qua Nav Rail hoặc Drawer |
| **Bảng dữ liệu bị bóp méo, cuộn ngang** | Danh sách khách hàng và thông tin liên hệ | **100% Full-Width CRM Data Table** có sticky header và avatar |
| **Nút bấm rải rác lộn xộn** | Thao tác trên nhiều khách hàng đã tick chọn | **Floating Dynamic Island Action Dock** tự động trồi lên ở đáy màn hình |
| **Form cấu hình đè lên kết quả** | Thiết lập chỉ tiêu và chế độ quét ban đầu | **Campaign Setup View** tập trung, chuyển view mượt mà khi bấm Bắt đầu |

---

## 3. KIẾN TRÚC THÔNG TIN MỚI (INFORMATION ARCHITECTURE)

Giao diện được tái cấu trúc thành **4 tầng không gian chuyên biệt (App Shell Architecture)**:

```
┌─────────────────────────────────────────────────────────────────────────────────────────────────────────┐
│ TẦNG 1: TOP COMMAND BAR (Thanh lệnh & Ngữ cảnh toàn cục)                                                │
│ Facebook / Nhóm mục tiêu / [Tên Nhóm Facebook]               [Xuất Excel] [Auto Kết bạn] [Dừng] [X]     │
├───────────────────┬─────────────────────────────────────────────────────────────────────────────────────┤
│ TẦNG 2: NAV RAIL  │ TẦNG 3: MAIN WORKSPACE CANVAS                                                       │
│ (240px Cố định)   │                                                                                     │
│                   │ ┌─────────────────────────────────────────────────────────────────────────────────┐ │
│ [Logo] FAIRY HOUSE│ │ KPI ROW: [ 1.250 UID ]  [ 842 SĐT (Hero) ]  [ Thiếu 158 ]  [ Tiến độ 84% ]      │ │
│ V2.0 PRO          │ ├─────────────────────────────────────────────────────────────────────────────────┤ │
│ ● Sẵn sàng        │ │ MULTI-VIEW VIEWPORT (Chuyển đổi theo Nav Rail):                                 │ │
│                   │ │                                                                                 │ │
│ 📋 Khách hàng     │ │ • VIEW 1: CRM LEADS WORKSTATION                                                 │ │
│    [ Badge 842 ]  │ │   - Thanh lọc (Search + Giới tính + Đầu số + Khu vực)                           │ │
│                   │ │   - Bảng khách hàng 100% Full-Width (Sticky Header, Avatar, SĐT Monospace)      │ │
│ 📊 Phân tích      │ │                                                                                 │ │
│    đối tượng      │ │ • VIEW 2: AUDIENCE INSIGHTS CANVAS                                              │ │
│                   │ │   - Biểu đồ Donut Giới tính (Nam/Nữ)                                            │ │
│ ⚙️ Thiết lập      │ │   - Thước đo phân bổ Đầu số Nhà mạng (09x cổ vs 03x mới)                        │ │
│    chiến dịch     │ │   - Mật độ phân bổ Tỉnh/Thành & Tháp tuổi                                       │ │
│                   │ │                                                                                 │ │
│ ───────────────── │ │ • VIEW 3: CAMPAIGN SETUP VIEW                                                   │ │
│ 📍 Tên Nhóm quét  │ │   - Nhập chỉ tiêu khách hàng (1 – 50.000)                                       │ │
│ 📞 0378.791.667   │ │   - Lựa chọn chế độ Quét nhanh / Quét sâu                                       │ │
│ (Zalo Hỗ trợ)     │ └─────────────────────────────────────────────────────────────────────────────────┘ │
│                   │ ┌─────────────────────────────────────────────────────────────────────────────────┐ │
│                   │ │ TẦNG 4: FLOATING MULTI-SELECT ACTION DOCK (Tự động trồi lên khi có checkbox)    │ │
│                   │ │ [ ✓ Đã chọn 12 khách hàng ]     [ ⚡ Auto Kết bạn ]     [ 📥 Xuất Excel ]       │ │
│                   │ └─────────────────────────────────────────────────────────────────────────────────┘ │
└───────────────────┴─────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 4. CHI TIẾT TỪNG PHÂN VÙNG BỐ CỤC

### 4.1. Left Navigation Rail (`#zt-nav-rail`)
* **Brand Header:** Logo 38px sắc nét, Heading "Fairy House", Version Badge "V2.0 PRO".
* **Live Status Pill (`#zt-badge-live-status`):** Đèn tín hiệu trạng thái tự động đổi màu theo tiến trình (Xanh lá `Sẵn sàng`/`Đang quét`, Vàng `Tạm dừng`, Đỏ `Đã dừng`).
* **Nav Items:**
  * `📋 Khách hàng` (`#zt-nav-tab-leads`): Đi kèm counter badge nhảy số SĐT realtime.
  * `📊 Phân tích đối tượng` (`#zt-nav-tab-analytics`): Mở màn hình phân tích toàn cảnh.
  * `⚙️ Thiết lập chiến dịch` (`#zt-nav-tab-setup`): Cấu hình tham số quét.
* **Footer Ngữ cảnh:** Avatar + Tên Group/Page đang quét + Hotline hỗ trợ Zalo.

### 4.2. Top Command Bar (`#zt-top-bar`)
* **Breadcrumb:** Hiển thị vị trí làm việc `Facebook / [Tên Nhóm/Page]`.
* **Cụm Action Chính:** `Xuất Excel` (Teal Hero), `Xuất UID`, `CSV`, `Auto Kết bạn`.
* **Cụm Điều khiển Quét:** `Tạm dừng`, `Kết thúc`, nút Đóng `[X]`.

### 4.3. KPI Metric Row (`#zt-section-scan`)
* 4 thẻ số liệu SaaS hiện đại:
  1. **UID Đã quét** (`#zt-stat-uids`)
  2. **Đã ra số điện thoại** (`#zt-stat-phones` - Thẻ nổi bật Hero Teal)
  3. **Mục tiêu còn thiếu** (`#zt-stat-remain` - Thẻ cảnh báo Amber)
  4. **Tiến độ quét** (`#zt-progress-label` kèm thanh progress bar mượt mà)

### 4.4. CRM Leads Data Table 100% Full-Width
* Bộ lọc tích hợp: Ô tìm kiếm tức thì, dropdown Giới tính, dropdown Đầu số nhà mạng, dropdown Khu vực.
* Bảng dữ liệu thoáng đãng:
  * Checkbox chọn từng dòng + checkbox chọn tất cả (`#zt-select-all`).
  * Cột Avatar tròn 24px phân biệt Nam/Nữ.
  * Họ tên in đậm rõ ràng.
  * Số điện thoại dùng font JetBrains Monospace dễ đọc, có nút copy nhanh.
  * Cột Khu vực, Độ tuổi, Điểm tiềm năng hiển thị trực quan.

### 4.5. Floating Action Dock (`#zt-floating-dock`)
* Ẩn hoàn toàn khi chưa chọn dòng nào.
* Khi tick chọn $\ge 1$ dòng: Tự động trồi lên ở vị trí giữa đáy màn hình (hiệu ứng blur 16px).
* Hiển thị: `[✓ Đã chọn N khách]` kèm 2 nút bấm nhanh `⚡ Auto Kết bạn` và `📥 Xuất Excel`.

### 4.6. Expansive Analytics Dashboard (`#zt-sidebar`)
* Không còn là một sidebar hẹp 260px.
* Biến thành một Dashboard 2 cột rộng rãi:
  * Biểu đồ tròn Donut cơ cấu giới tính Nam / Nữ (`#zt-pie-gender`, `#zt-sb-male`, `#zt-sb-female`).
  * Thước đo tỷ lệ đầu số nhà mạng 09x cổ vs 03x mới (`#zt-sb-prefix-09`, `#zt-sb-prefix-03`).
  * Bảng xếp hạng mật độ Tỉnh/Thành phố (`#zt-region-tbody`, `#zt-pie-city`).
  * Tháp phân bổ độ tuổi khách hàng (`#zt-age-bars`).

---

## 5. LUỒNG TRẢI NGHIỆM NGƯỜI DÙNG (NEW USER FLOWS)

```mermaid
graph TD
    A[Mở Popup Extension] --> B{Kiểm tra Key?}
    B -- Hợp lệ --> C[Hiển thị Hero Quota còn lại]
    B -- Chưa có/Hết hạn --> D[Form nhập Key & Kích hoạt]
    C --> E[Bấm 'Mở Facebook để quét']
    
    E --> F[Vào Group/Page Facebook]
    F --> G[Bấm nút 'Fairy House' trên trang]
    G --> H[Mở Workstation 1440px x 92vh]
    
    H --> I[Giai đoạn Setup: Nhập số lượng & Chọn chế độ]
    I --> J[Bấm 'Bắt đầu chiến dịch']
    
    J --> K[Giai đoạn Quét Realtime]
    K --> L[Nav Rail nhảy số SĐT + Top KPI cập nhật]
    K --> M[Bảng CRM đổ dữ liệu 100% full-width]
    
    M --> N{Thao tác người dùng}
    N -- Xem biểu đồ --> O[Click 'Phân tích đối tượng' trên Nav Rail]
    N -- Tick chọn dòng --> P[Floating Action Dock trồi lên]
    P --> Q[Click 'Auto Kết bạn' hoặc 'Xuất Excel']
```

---

## 6. THIẾT KẾ RESPONSIVE & ADAPTIVE

Giao diện tự động co giãn thông minh không phụ thuộc một kích thước cố định:
* **Màn hình lớn / Full HD (≥ 1440px):** Khung nhìn mở rộng tối đa `1440px × 92vh`. Left Rail rộng 240px, bảng hiển thị đầy đủ 8 cột thông tin.
* **Laptop trung bình (1024px – 1366px):** Chiều rộng tự thích ứng theo `min(1440px, 96vw)`. Các cột phụ (Tuổi, Điểm) tự ẩn hoặc thu nhỏ, ưu tiên SĐT, Tên, Vị trí.
* **Màn hình nhỏ (< 1024px):** Dải KPI chuyển thành lưới 2×2, các nút trên Top Bar rút gọn văn bản thành icon có tooltip.
* **Chống giật kích thước (Zero-Jump):** Viewport giữ vững 92vh xuyên suốt từ lúc cấu hình đến lúc quét xong, loại bỏ hiện tượng co rút cửa sổ.
* **Chống nhấp nháy FOUC:** Toàn bộ icon SVG có kích thước cố định (`14x14`, `16x16`), preloader chuyển cảnh mượt trong khi nạp tài nguyên.

---

## 7. BẢN ĐỒ KẾT NỐI TOÀN VẸN 100% BUSINESS LOGIC (118 DOM IDS)

Mọi ID mà [`src/ui/modal.js`](file:///e:/Target/zoo-target-pro/src/ui/modal.js) yêu cầu đều được định vị chính xác trong cấu trúc mới:

1. **Điều khiển chiến dịch:** `#zt-btn-start`, `#zt-btn-pause`, `#zt-btn-finish`, `#zt-btn-close`.
2. **Xuất tệp & Auto Invite:** `#zt-btn-export-xlsx`, `#zt-btn-export-uid`, `#zt-btn-fanpage-csv`, `#zt-btn-auto-invite`.
3. **Thống kê & Tiến trình:** `#zt-stat-uids`, `#zt-stat-phones`, `#zt-stat-remain`, `#zt-stat-remain-wrap`, `#zt-progress-fill`, `#zt-progress-label`, `#zt-status-card`, `#zt-status-phase`, `#zt-status-detail`, `#zt-status-spinner`.
4. **Bộ lọc & Bảng dữ liệu:** `#zt-filter-bar`, `#zt-filter-search`, `#zt-filter-gender`, `#zt-filter-prefix`, `#zt-filter-region`, `#zt-filter-region-wrap`, `#zt-table-scroll`, `#zt-results-table`, `#zt-select-all`, `#zt-tbody`, `#zt-empty-state`, `#zt-empty-phase`, `#zt-empty-detail`, `#zt-empty-dots`, `#zt-empty-spinner`, `#zt-empty-hint`.
5. **Phân tích đối tượng:** `#zt-sidebar`, `#zt-pie-gender`, `#zt-sb-male`, `#zt-sb-female`, `#zt-sb-prefix-09`, `#zt-sb-prefix-03`, `#zt-pie-city`, `#zt-region-tbody`, `#zt-age-bars`, `#zt-sidebar-age-wrap`, `#zt-sidebar-region-wrap`.
6. **Cấu hình chiến dịch:** `#zt-section-config`, `#zt-config-card`, `#zt-config-resolving`, `#zt-config-resolving-text`, `#zt-input-limit`, `#zt-limit-wrap`, `#zt-scan-depth-fast`, `#zt-scan-depth-deep`, `#zt-scan-depth-fieldset`.
7. **Hộp thoại Overlays:** `#zt-confirm`, `#zt-confirm-msg`, `#zt-confirm-ok`, `#zt-confirm-cancel`, `#zt-notice-modal`, `#zt-notice-title`, `#zt-notice-message`, `#zt-notice-ok`, `#zt-success-modal`, `#zt-success-ok`, `#zt-invite-config-modal`, `#zt-invite-progress-panel`, `#zt-error-panel`, `#zt-error-text`, `#zt-toast`.

---

## 8. KẾ HOẠCH TRIỂN KHAI 5 GIAI ĐOẠN

* **Giai đoạn 1: Chuẩn hóa Design System & Tokens**
  * Tinh chỉnh `src/ui/styles.css` thành hệ thống biến `--primary`, `--surface`, `--border`.
  * Khai báo layout rules: `.zt-nav-rail`, `.zt-kpi-card`, `.zt-floating-dock`, `.zt-scrollbar`.
* **Giai đoạn 2: Tái cấu trúc Popup License (`action-popup.html`)**
  * Thiết kế lại khung nhìn 380px compact, loại bỏ hoàn toàn đè logo cũ/mới.
  * Phân tách 9 trạng thái License Key (Hợp lệ, Hết hạn, Trùng máy, Lỗi mạng).
* **Giai đoạn 3: Tái cấu trúc Modal Workstation (`modal.html`)**
  * Xây dựng App Shell mới: Left Navigation Rail + Top Command Bar + Dynamic Stage.
  * Lắp ráp 3 View độc lập: CRM Leads Table, Analytics Dashboard, Campaign Setup.
* **Giai đoạn 4: Liên kết Logic & Trình nhúng Iframe (`content/index.js`)**
  * Giữ vững kích thước Workstation `min(1440px, 96vw) × 92vh`.
  * Chạy script tự động xác thực 118/118 DOM IDs.
* **Giai đoạn 5: Kiểm thử hoàn thiện & Nghiệm thu**
  * Kiểm tra cú pháp JavaScript qua `node -c`.
  * Kiểm tra hiển thị thực tế trên các màn hình laptop và desktop.

---

## 9. TIÊU CHÍ NGHIỆM THU

* [x] Bố cục cũ bị xóa bỏ hoàn toàn; thay thế bằng chuẩn Enterprise SaaS Workstation.
* [x] Có Left Navigation Rail điều hướng chuyên nghiệp kèm Live Status và Counter Badge.
* [x] Bảng dữ liệu chiếm 100% diện tích, không bị bất kỳ sidebar nào chèn ép.
* [x] Biểu đồ phân tích được mở rộng thành một Dashboard toàn màn hình khi cần.
* [x] Thao tác chọn nhiều có Floating Action Dock thông minh ở đáy màn hình.
* [x] Khung nhìn giữ vững 92vh, không bị co rút hay giật kích thước.
* [x] Triệt tiêu hoàn toàn lỗi nhấp nháy icon to (Zero-FOUC).
* [x] 100% chức năng cũ và 118 DOM IDs hoạt động chính xác.
